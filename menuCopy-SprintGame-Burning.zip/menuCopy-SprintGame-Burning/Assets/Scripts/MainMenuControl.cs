﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class MainMenuControl : MonoBehaviour
{
    private GameObject mainMenu;
    private GameObject optionMenu;
    
    void Start(){
        mainMenu = GameObject.Find("MainMenu");
        optionMenu = GameObject.Find("OptionMenu");
    }
    
    public void PlayGame(){
        SceneManager.LoadScene(1);
    }

    public void QuitGame(){
        Debug.Log("Quit");
        Application.Quit();
    }

    public void OptionsMenuSet(){
        optionMenu.gameObject.SetActive(true);
        mainMenu.gameObject.SetActive(false);
    }

    public void BackOption(){
        optionMenu.gameObject.SetActive(false);
        mainMenu.gameObject.SetActive(true);
    }
    
}

